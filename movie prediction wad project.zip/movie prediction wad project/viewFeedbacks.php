<?php

    $con=new mysqli("localhost","root","","userdatabase");
   
    $q = "select * from feedbackreceived";
    $rs = $con->query($q);
?>
<!DOCTYPE html>
<html>
<head>
  <title>View FeedBack Page</title>
   <link href="associated/img/logoM2A.png" rel="icon">
   <!--css file-->
     <link rel="stylesheet" type="text/css" href="associated/css/reviews.css">
     <!--bootstrap css-->
     <link href="associated/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body id="ovbg">
<div id="top">
<h1>M2A Feedbacks & rating</h1>
<a href= "index.php" ><button class="customButton">Back to Home</button></a>
</div>
<div id="contentSet">
    <?php
      while ($r = $rs->fetch_assoc()) {
        echo "<div id=iterativeContent>";
        echo "<h2>";
        echo $r["name"];
        echo "</h2>";
        echo "<h4>";
        echo $r["ratings"];
        echo "</h4>";
        echo "<h3 id=apperanceY>";
        echo "Feedback";
        echo "</h3>";
        echo "<h5>";
        echo $r["opinion"];
        echo "</h5>";
        echo "</div>";
      }
  ?>
  
</div>
<div id="footer">
  <div class="row">
      <div class="col-sm-12">
        
        <div id="copyright-box">
            <p id="copyright">&copy; Copyright <strong>@2022</strong>. All Rights Reserved</p>
            <div id="credits">
              Designed by <u><a href="https://m.facebook.com/Team-M2A-101507989120077/?__tn__=~~-R">Team M2A</a></u>
            </div>
        </div>
      </div>
  </div>
</div>
</body>
</html>


