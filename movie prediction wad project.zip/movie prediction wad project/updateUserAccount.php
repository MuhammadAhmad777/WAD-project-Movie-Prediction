<!DOCTYPE html>
<html>
<head>
	<title>M2A Historial Data Updation</title>
	 <link href="associated/img/logoM2A.png" rel="icon">
	 <!--css file-->
  	 <link rel="stylesheet" type="text/css" href="associated/css/adminChanges.css">
  	 <!--bootstrap css-->
  	 <link href="associated/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>


<!-- ======= Hero Section ======= -->
  <div id="hero" class="hero route bg-image" style="background-image: url(associated/img/letsChangeBg.jpg)">
    <div class="overlay-itro"></div>
    <div class="hero-content display-table">
    <?php
		session_start();
		if (isset($_SESSION["adminName"]))
		{
			$con=new mysqli("localhost","root","","userdatabase");
			$q = "select * from useraccounts where email='".$_GET["email"]."'";
			$rs = $con->query($q);
			$r= $rs->fetch_assoc();
	?>
      <div class="table-cell">
        <div class="container">
			<h2 class="hero-title mb-4">User Account Updation</h2>
			<p class="hero-subtitle">Modify User Account</p>
			<form action="updateActionUserAccount.php" method="POST">
				Enter your Name
				<input type="text" name="name" placeholder="New User Name" value="<?php echo $r["name"]; ?>" required><br><br>
				Enter your Email
				<input type="text" name="newemail" placeholder="New User Email" value="<?php echo $r["email"]; ?>" required><br><br>
				Enter your Password
				<input type="password" name="password" placeholder="New User Password" value="<?php echo $r["password"]; ?>" required><br><br>
				<input type="hidden" name="email"  value="<?php echo $r["email"]; ?>"> <br><br>
				<input type="submit" value="submit data" class="customButton">
				<input type="reset" value="Clear it" class="customButton"><br><br>
         	</form>
         	<a href= "viewUserAccounts.php" ><button class="customButton">Back</button></a>
        </div>
      </div>
     <?php
		}
		else
		{
			echo "<h1>You're already signed out<h1>";
		}
	?>
    </div>
  </div><!-- End Hero Section -->
  <div id="footer">
  <div class="row">
      <div class="col-sm-12">
        
        <div id="copyright-box">
            <p id="copyright">&copy; Copyright <strong>@2022</strong>. All Rights Reserved</p>
            <div id="credits">
              Designed by <u><a href="https://m.facebook.com/Team-M2A-101507989120077/?__tn__=~~-R">Team M2A</a></u>
            </div>
        </div>
      </div>
  </div>
</div>
</body>
</html>