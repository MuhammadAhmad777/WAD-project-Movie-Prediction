<!DOCTYPE html>
<html>
<head>
	<title>M2A Historial Data Updation</title>
	 <link href="associated/img/logoM2A.png" rel="icon">
	 <!--css file-->
  	 <link rel="stylesheet" type="text/css" href="associated/css/adminChanges.css">
  	 <!--bootstrap css-->
  	 <link href="associated/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>


<!-- ======= Hero Section ======= -->
  <div id="hero" class="hero route bg-image" style="background-image: url(associated/img/letsChangeBg.jpg)">
    <div class="overlay-itro"></div>
    <div class="hero-content display-table">
    <?php
		session_start();
		if (isset($_SESSION["adminName"]))
		{
			$con=new mysqli("localhost","root","","userdatabase");
			$q = "select * from historicaldata where mvid='".$_GET["id"]."'";
			$rs = $con->query($q);
			$r= $rs->fetch_assoc();
	?>
      <div class="table-cell">
        <div class="container">
			<h2 class="hero-title mb-4">Historical Data Updation</h2>
			<p class="hero-subtitle">Update required factors</p>
			<form action="updateActionHistorical.php" method="POST">
			<table cellpadding="10px">
				
				<tr>
					<td>Movie Name
					<input type="text" name="movieName" placeholder="Movie Name"  value="<?php echo $r["movieName"]; ?>" required>
					</td>
					<td>Male
					<input type="text" name="Character1" placeholder="Leading Actor"  value="<?php echo $r["actor"]; ?>" required>
					</td>
					<td>Female
					<input type="text" name="Character2" placeholder="Leading Actress"  value="<?php echo $r["actress"]; ?>" required>
					</td>
				</tr>
				<tr>
					<td>Release Date
					<input type="date" name="date" placeholder="Date"   value="<?php echo $r["date"]; ?>" required>
					</td>
					<td>Produced By
					<input type="text" name="producerName" placeholder="Producer Name"  value="<?php echo $r["producerName"]; ?>" required>
					</td>
					<td>Directed By
					<input type="text" name="directorName" placeholder="Director Name"  value="<?php echo $r["directorName"]; ?>" required>
					</td>
				</tr>
				<tr>
					<td>Written By
					<input type="text" name="writtenBy" placeholder="Writter Name"  value="<?php echo $r["writtenBy"]; ?>" required>
					</td>
					<td>Budget
					<input type="text" name="budget" placeholder="Budget(US$ million)"   value="<?php echo $r["budget"]; ?>" required>
					</td>
					<td>Running Time
					<input type="text" name="runningTime" placeholder="Running Time(minutes)"   value="<?php echo $r["runningTime"]; ?>" required>
					</td>
				</tr>
				<tr>
					<td>Result
					<input type="text" name="result" placeholder="hit/average/flop"  value="<?php echo $r["result"]; ?>" required><br><br>
					</td>
					<input type="hidden" name="mvid" value="<?php echo $r["mvid"]; ?>">
				</tr>
			</table>
				<input type="submit" value="submit data" class="customButton">
				<input type="reset" value="Clear it" class="customButton"><br><br>
         	</form>
         	<a href= "viewHistoricalData.php" ><button class="customButton">Back</button></a>
        </div>
      </div>
     <?php
		}
		else
		{
			echo "<h1>You're already signed out<h1>";
		}
	?>
    </div>
  </div><!-- End Hero Section -->
  <div id="footer">
  <div class="row">
      <div class="col-sm-12">
        
        <div id="copyright-box">
            <p id="copyright">&copy; Copyright <strong>@2022</strong>. All Rights Reserved</p>
            <div id="credits">
              Designed by <u><a href="https://m.facebook.com/Team-M2A-101507989120077/?__tn__=~~-R">Team M2A</a></u>
            </div>
        </div>
      </div>
  </div>
</div>
</body>
</html>