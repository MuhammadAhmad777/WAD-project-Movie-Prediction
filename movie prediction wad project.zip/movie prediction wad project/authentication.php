<?php

$n=$_POST["name"];
$e=$_POST["email"];
$p=$_POST["password"];

$con=new mysqli("localhost","root","","userdatabase");
$q="select * from useraccounts where name='$n' AND email='$e' AND password='$p'";	
$rs = $con->query($q);
if($rs->num_rows ==1)
{
	session_start();
	$_SESSION["name"]=$n;
	$_SESSION["email"]=$e;
	$_SESSION["password"]=$p;
	header("Location:afterSignIn.php");
}
else
{
	header("Location:signIn.php");
}
$con->close();

?>