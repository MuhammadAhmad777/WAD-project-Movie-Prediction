<?php
$name=$_POST["name"];
$email=$_POST["email"];
$pass=$_POST["password"];


$con=new mysqli("localhost","root","","userdatabase");
$q="insert into useraccounts(name,email,password)values('".$name."','".$email."','".$pass."')";
if($con->query($q)==TRUE)
{
	session_start();
	$_SESSION["name"]=$name;
	$_SESSION["email"]=$email;
	$_SESSION["password"]=$pass;
	header("Location:signIn.php");
}
else
{
	echo $con->error;
}


$con->close();
?>
