<?php

class threeCategories{
	//data members
	protected $hit;
	protected $avg;
	protected $flop;
	//constructor
	public function __construct($hit=0,$avg=0,$flop=0)
	{
		$this->hit=$hit;
		$this->avg=$avg;
		$this->flop=$flop;
	}
	//simple getters
	public function get_hit()
	{
		return $this->hit;
	}
	public function get_avg()
	{
		return $this->avg;
	}
	public function get_flop()
	{
		return $this->flop;
	}
	public function get_total()
	{
		$total=$this->hit+$this->avg+$this->flop;
		return $total;
	}
	//simple setters
	public function set_hit($hit)
	{
		$this->hit=$hit;
	}
	public function set_avg($avg)
	{
		$this->avg=$avg;
	}
	public function set_flop($flop)
	{
		$this->flop=$flop;
	}
	
}

$movieName=$_POST["movieName"];
$Character1=$_POST["Character1"];
$Character2=$_POST["Character2"];
$dateRel=$_POST["date"];
$producerN=$_POST["producerName"];
$directorN=$_POST["directorName"];
$writtenBy=$_POST["writtenBy"];
$budget=$_POST["budget"];
$runningTime=$_POST["runningTime"];


//created connection
$con=new mysqli("localhost","root","","userdatabase");

//created actor object of class threeCategories
$actor=new threeCategories();
//run query
$q = "select * from historicaldata where actor='$Character1' AND result='hit'";
$rs = $con->query($q);
//set number of rows as number of times hit
$actor->set_hit($rs->num_rows);

//set number of rows as number of times average
$q = "select * from historicaldata where actor='$Character1' AND result='average'";
$rs = $con->query($q);
$actor->set_avg($rs->num_rows);

//set number of rows as number of times flop
$q = "select * from historicaldata where actor='$Character1' AND result='flop'";
$rs = $con->query($q);
$actor->set_flop($rs->num_rows);


//created actress object of class threeCategories
$actress=new threeCategories();
//run query
$q = "select * from historicaldata where actress='$Character2' AND result='hit'";
$rs = $con->query($q);
//set number of rows as number of times hit
$actress->set_hit($rs->num_rows);

//set number of rows as number of times average
$q = "select * from historicaldata where actress='$Character2' AND result='average'";
$rs = $con->query($q);
$actress->set_avg($rs->num_rows);

//set number of rows as number of times flop
$q = "select * from historicaldata where actress='$Character2' AND result='flop'";
$rs = $con->query($q);
$actress->set_flop($rs->num_rows);



//created  object of class threeCategories
$date=new threeCategories();
//run query
$q = "select * from historicaldata where date='$dateRel' AND result='hit'";
$rs = $con->query($q);
//set number of rows as number of times hit
$date->set_hit($rs->num_rows);

//set number of rows as number of times average
$q = "select * from historicaldata where date='$dateRel' AND result='average'";
$rs = $con->query($q);
$date->set_avg($rs->num_rows);

//set number of rows as number of times flop
$q = "select * from historicaldata where date='$dateRel' AND result='flop'";
$rs = $con->query($q);
$date->set_flop($rs->num_rows);



//created  object of class threeCategories
$producer=new threeCategories();
//run query
$q = "select * from historicaldata where producerName='$producerN' AND result='hit'";
$rs = $con->query($q);
//set number of rows as number of times hit
$producer->set_hit($rs->num_rows);

//set number of rows as number of times average
$q = "select * from historicaldata where producerName='$producerN' AND result='average'";
$rs = $con->query($q);
$producer->set_avg($rs->num_rows);

//set number of rows as number of times flop
$q = "select * from historicaldata where producerName='$producerN' AND result='flop'";
$rs = $con->query($q);
$producer->set_flop($rs->num_rows);



//created  object of class threeCategories
$director=new threeCategories();
//run query
$q = "select * from historicaldata where directorName='$directorN' AND result='hit'";
$rs = $con->query($q);
//set number of rows as number of times hit
$director->set_hit($rs->num_rows);

//set number of rows as number of times average
$q = "select * from historicaldata where directorName='$directorN' AND result='average'";
$rs = $con->query($q);
$director->set_avg($rs->num_rows);

//set number of rows as number of times flop
$q = "select * from historicaldata where directorName='$directorN' AND result='flop'";
$rs = $con->query($q);
$director->set_flop($rs->num_rows);



//created  object of class threeCategories
$writer=new threeCategories();
//run query
$q = "select * from historicaldata where writtenBy='$writtenBy' AND result='hit'";
$rs = $con->query($q);
//set number of rows as number of times hit
$writer->set_hit($rs->num_rows);

//set number of rows as number of times average
$q = "select * from historicaldata where writtenBy='$writtenBy' AND result='average'";
$rs = $con->query($q);
$writer->set_avg($rs->num_rows);

//set number of rows as number of times flop
$q = "select * from historicaldata where writtenBy='$writtenBy' AND result='flop'";
$rs = $con->query($q);
$writer->set_flop($rs->num_rows);





//created  object of class threeCategories
$budg=new threeCategories();
//run query
$q = "select * from historicaldata where budget=$budget AND result='hit'";
$rs = $con->query($q);
//set number of rows as number of times hit
$budg->set_hit($rs->num_rows);

//set number of rows as number of times average
$q = "select * from historicaldata where budget=$budget AND result='average'";
$rs = $con->query($q);
$budg->set_avg($rs->num_rows);

//set number of rows as number of times flop
$q = "select * from historicaldata where budget=$budget AND result='flop'";
$rs = $con->query($q);
$budg->set_flop($rs->num_rows);







//created  object of class threeCategories
$duration=new threeCategories();
//run query
$q = "select * from historicaldata where runningTime=$runningTime AND result='hit'";
$rs = $con->query($q);
//set number of rows as number of times hit
$duration->set_hit($rs->num_rows);

//set number of rows as number of times average
$q = "select * from historicaldata where runningTime=$runningTime AND result='average'";
$rs = $con->query($q);
$duration->set_avg($rs->num_rows);

//set number of rows as number of times flop
$q = "select * from historicaldata where runningTime=$runningTime AND result='flop'";
$rs = $con->query($q);
$duration->set_flop($rs->num_rows);

$con->close();

$totalHitFactor=$actor->get_hit()+$actress->get_hit()+$date->get_hit()+$producer->get_hit()+$director->get_hit()+$writer->get_hit()+$budg->get_hit()+$duration->get_hit();

$totalAvgFactor=$actor->get_avg()+$actress->get_avg()+$date->get_avg()+$producer->get_avg()+$director->get_avg()+$writer->get_avg()+$budg->get_avg()+$duration->get_avg();

$totalFlopFactor=$actor->get_flop()+$actress->get_flop()+$date->get_flop()+$producer->get_flop()+$director->get_flop()+$writer->get_flop()+$budg->get_flop()+$duration->get_flop();

$totalOfAllFactors=$actor->get_total()+$actress->get_total()+$date->get_total()+$producer->get_total()+$director->get_total()+$writer->get_total()+$budg->get_total()+$duration->get_total();

$percentageHitFactor=($totalHitFactor/$totalOfAllFactors)*100;
$percentageAvgFactor=($totalAvgFactor/$totalOfAllFactors)*100;
$percentageFlopFactor=($totalFlopFactor/$totalOfAllFactors)*100;


?>
<!DOCTYPE html>
<html>
<head>
	<title>Prediction Result Generated</title>
	 <link href="associated/img/logoM2A.png" rel="icon">
	 <!--css file-->
  	 <link rel="stylesheet" type="text/css" href="associated/css/userPages.css">
  	 <!--bootstrap css-->
  	 <link href="associated/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>


<!-- ======= Hero Section ======= -->
  <div id="hero" class="hero route bg-image" style="background-image: url(associated/img/rslt.jpg)">
    <div class="overlay-itro"></div>
    	<div class="hero-content display-table">
      		<div class="table-cell">
        		<div class="container">
					<h2 class="hero-title mb-4">Prediction Result</h2>
			

	

<?php
if(($percentageHitFactor+$percentageAvgFactor)>$percentageFlopFactor)
{
	if($percentageHitFactor>=$percentageAvgFactor)
	{
		echo "<h3 style=color:white;>hit</h3>";
	}
	else
	{
		echo "<h3 style=color:white;>average</h3>";
			
	}
}
else
{
		echo "<h3 style=color:white;>flop</h3>";
}
?>			
					<a href= "afterSignIn.php" ><button class="customButton">Back</button></a>
					<a href= "signedout.php" ><button class="customButton">Sign out</button></a>
				</div>
			</div>
		</div>
	</div>
</body>
</html>