<?php



$name=$_POST["name"];
$email=$_POST["email"];
$ratings=$_POST["ratings"];
$op=$_POST["opinion"];


$con=new mysqli("localhost","root","","userdatabase");
$q="insert into feedbackreceived(name,email,ratings,opinion)values('".$name."','".$email."',".$ratings.",'".$op."')";
if($con->query($q)==TRUE)
{
?>
<script type="text/javascript">
	alert("Feedback Sent,Thank You");
 	window.location.replace('viewFeedbacks.php');	
</script>
<?php	
}
else
{
	echo $con->error;
}


$con->close();

?>
