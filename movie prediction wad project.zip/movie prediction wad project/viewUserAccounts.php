<?php
    $con=new mysqli("localhost","root","","userdatabase");
   
    $q = "select * from useraccounts";
    $rs = $con->query($q);
?>

<!DOCTYPE html>
<html>
<head>
  <title>View User Accounts Page</title>
   <link href="associated/img/logoM2A.png" rel="icon">
   <!--css file-->
     <link rel="stylesheet" type="text/css" href="associated/css/adminView.css">
     <!--bootstrap css-->
     <link href="associated/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body id="ovbg">
<div id="top">
<h1>M2A Admin View User Accounts</h1>
<a href= "afterAdminSignIn.php" ><button class="customButton">Back</button></a>
</div>
<?php
  session_start();
  if (isset($_SESSION["adminName"]))
  {
?>
<div id="contentSet">
      <?php
        echo "<center><table style:width=80% border=1>";
        echo "<tr>";
        echo "<th class=tableData>Name</th><th class=tableData>Email</th><th class=tableData>Password</th>";
        echo "</tr>";
        while ($r = $rs->fetch_assoc()) 
        {
            echo "<tr>";
            
            echo "<td class=tableData>".$r["name"]."</td>";
            echo "<td class=tableData>".$r["email"]."</td>";
            echo "<td class=tableData>".$r["password"]."</td>";
            echo "<td class=tableData><a href='deleteUserAccount.php?email=".$r["email"]."'> Delete </a></td>";
            echo "<td class=tableData><a href='updateUserAccount.php?email=".$r["email"]."'> Update </a></td>";
            echo "</tr>";
        }
        echo "</table></center>"

      ?>   
  </div>

<?php
  }
  else
  {
    echo "You're already signed out";
  }
?>
<div id="footer">
  <div class="row">
      <div class="col-sm-12">
        
        <div id="copyright-box">
            <p id="copyright">&copy; Copyright <strong>@2022</strong>. All Rights Reserved</p>
            <div id="credits">
              Designed by <u><a href="https://m.facebook.com/Team-M2A-101507989120077/?__tn__=~~-R">Team M2A</a></u>
            </div>
        </div>
      </div>
  </div>
</div>
</body>
</html>