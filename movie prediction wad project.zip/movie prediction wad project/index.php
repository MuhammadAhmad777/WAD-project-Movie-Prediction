<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>M2A Movie Predictor</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="associated/img/logoM2A.png" rel="icon">
 



  <!-- Vendor CSS Files -->
  <link href="associated/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="associated/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
   <link href="associated/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="associated/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="associated/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

   <!-- Template Main CSS File -->
  <link href="associated/css/home.css" rel="stylesheet">
 
</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top">
    <div class="container d-flex align-items-center justify-content-between">
    	<a href="index.php" class="logo"><img src="associated/img/logoM2A.png" alt="logo" class="img-fluid"></a>
      <h1 class="logo"><a href="index.php">M2A Movie Predictor</a></h1>
     
      
	   <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#contact">Feedback</a></li>
          <li><a  href="signUp.php">Register</a></li>
          <li><a  href="signIn.php">Sign in</a></li>
           <li><a  href="adminSignIn.php">Admin</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>	
       </nav><!-- .navbar -->
	
    </div>
  </header><!-- End Header -->

  <!-- ======= Hero Section ======= -->
  <div id="hero" class="hero route bg-image" style="background-image: url(associated/img/homebg.jpg)">
    <div class="overlay-itro"></div>
    <div class="hero-content display-table">
      <div class="table-cell">
        <div class="container">
         
          <h1 class="hero-title mb-4">Welcome to our site</h1>
          <p class="hero-subtitle">Register or Sign in to predict</p>
          <a href="signUp.php"><button class="customButton">Register here</button></a>
         <a href="signIn.php"><button class="customButton">Sign in here</button></a><br><br>
         <a href="adminSignIn.php"><button class="customButton">Interact as Admin?</button></a>
        </div>
      </div>
    </div>
  </div><!-- End Hero Section -->

  <main id="main">

    <!-- ======= About Section ======= -->
    <section id="about" class="about-mf sect-pt4 route">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
            <div class="title-box text-center">
              <h3 class="title-a">
                About Us
              </h3>
              <p class="subtitle-a">
                Get to Know us
              </p>
              <div class="line-mf"></div>
            </div>
          </div>
        </div>
        <div class="row">
          <div class="col-sm-12">
            <div class="box-shadow-full">
            <p>On this site, you can predict the success of movie just by input required detail.
            It is our site's policy to first register yourself on this site or if you are already registered then just login and continue to predict movie'success.We would be happy to get to know about your experience using this site.Hence, for that you can send us your views in Feedback Section.Here, please note that feedback section is public.</p>
            </div>
          </div>
        </div>
      </div>
    </section><!-- End About Section -->





   
     

<!-- ======= Contact Me Section ======= -->
    <section id="contact" class="contact my_customizeAdjustment">
      <div class="container">
        <div class="row">
          <div class="col-sm-12">
              <div class="title-box text-center">
                  <h3 class="title-a">
                      Feedback
                  </h3>
                  <p class="subtitle-a">
                     Your experience using this site
                  </p>
                  <div class="line-mf"></div>
               </div>
              </div>
        </div>

        <div class="row">

          <div class="col-sm-12">
            <form action="feedback.php" method="POST" role="form" class="php-email-form">
              <div class="row">
                <div class="col-sm-6 form-group">
                  <input type="text" name="name" class="form-control" id="name" placeholder="Your Name" required>
                </div>
                <div class="col-sm-6 form-group mt-3 mt-md-0">
                  <input type="email" class="form-control" name="email" id="email" placeholder="Your Email" required>
                </div>
              </div>
              <div class="form-group mt-3">
                <input type="text"  name="ratings" pattern="[0-9]{1,2}" class="form-control" id="ratings" placeholder="Rate out of 10" required>
              </div>
              <div class="form-group mt-3">
                <textarea class="form-control" name="opinion" rows="6" placeholder="Feedback(Optional)"></textarea>
              </div>
             
              <center><button type="submit" class="customButton">Send FeedBack</button></center>
             
            </form>
            <center> <a href= "viewFeedbacks.php" ><button class="customButton">See Feedbacks</button></a></center>
          </div>
        </div>
      </div>
    </section><!-- End Contact Me Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer>
    <div class="container">
      <div class="row">
        <div class="col-sm-12">
          <div class="copyright-box">
            <p class="copyright">&copy; Copyright <strong>@2022</strong>. All Rights Reserved</p>
            <div class="credits">
              Designed by <u><a href="https://m.facebook.com/Team-M2A-101507989120077/?__tn__=~~-R">Team M2A</a></u>
            </div>
          </div>
        </div>
      </div>
    </div>
  </footer><!-- End  Footer -->

 <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="associated/vendor/purecounter/purecounter.js"></script>
  <script src="associated/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="associated/vendor/glightbox/js/glightbox.min.js"></script>

<!--
<script src="associated/vendor/isotope-layout/isotope.pkgd.min.js"></script
-->
  <script src="associated/vendor/swiper/swiper-bundle.min.js"></script>

  
  <script src="associated/vendor/waypoints/noframework.waypoints.js"></script>
  

  <script src="associated/vendor/typed.js/typed.min.js"></script>

  <!--
  <script src="associated/vendor/php-email-form/validate.js"></script>
-->

  <!-- Template Main JS File -->
  <script src="associated/js/main.js"></script>

</body>

</html>