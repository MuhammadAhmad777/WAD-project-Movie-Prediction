<?php
    $con=new mysqli("localhost","root","","userdatabase");
   
    $q = "select * from historicaldata";
    $rs = $con->query($q);
?>

<!DOCTYPE html>
<html>
<head>
  <title>View Historical Data Page</title>
   <link href="associated/img/logoM2A.png" rel="icon">
   <!--css file-->
     <link rel="stylesheet" type="text/css" href="associated/css/adminView.css">
     <!--bootstrap css-->
     <link href="associated/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>
<body id="ovbg">
<div id="top">
<h1>M2A Movies Historical Data</h1>
<a href= "afterAdminSignIn.php" ><button class="customButton">Back</button></a>
</div>
<?php
  session_start();
  if (isset($_SESSION["adminName"]))
  {
?>
<div id="contentSet">
      <?php
        echo "<center><table style:width=80% border=1>";
        echo "<tr>";
        echo "<th class=tableData>Movie Name</th><th class=tableData>Actor Name</th><th class=tableData>Actress Name</th>";
        echo "<th class=tableData>date</th><th class=tableData>Producer</th><th class=tableData>Director</th>";
        echo "<th>Writer</th><th class=tableData>Budget</th><th class=tableData>Duration</th>";
        echo "<th class=tableData>Result</th>";
        echo "</tr>";
        while ($r = $rs->fetch_assoc()) 
        {
            echo "<tr>";
            
            echo "<td class=tableData>".$r["movieName"]."</td>";
            echo "<td class=tableData>".$r["actor"]."</td>";
            echo "<td class=tableData>".$r["actress"]."</td>";
            echo "<td class=tableData>".$r["date"]."</td>";
            echo "<td class=tableData>".$r["producerName"]."</td>";
            echo "<td class=tableData>".$r["directorName"]."</td>";
            echo "<td class=tableData>".$r["writtenBy"]."</td>";
            echo "<td class=tableData>".$r["budget"]."</td>";
            echo "<td class=tableData>".$r["runningTime"]."</td>";
            echo "<td class=tableData>".$r["result"]."</td>";
            echo "<td class=tableData><a href='deleteHistorical.php?id=".$r["mvid"]."'> Delete </a></td>";
            echo "<td class=tableData><a href='updateHistorical.php?id=".$r["mvid"]."'> Update </a></td>";
            echo "</tr>";
        }
        echo "</table></center>"

      ?>   
  </div>

<?php
  }
  else
  {
    echo "You're already signed out";
  }
?>
<div id="footer">
  <div class="row">
      <div class="col-sm-12">
        
        <div id="copyright-box">
            <p id="copyright">&copy; Copyright <strong>@2022</strong>. All Rights Reserved</p>
            <div id="credits">
              Designed by <u><a href="https://m.facebook.com/Team-M2A-101507989120077/?__tn__=~~-R">Team M2A</a></u>
            </div>
        </div>
      </div>
  </div>
</div>
</body>
</html>