<?php
$inworkid=$_POST["mvid"];
$movieName=$_POST["movieName"];
$Character1=$_POST["Character1"];
$Character2=$_POST["Character2"];
$dateRel=$_POST["date"];
$producerN=$_POST["producerName"];
$directorN=$_POST["directorName"];
$writtenBy=$_POST["writtenBy"];
$budget=$_POST["budget"];
$runningTime=$_POST["runningTime"];
$outcome=$_POST["result"];
$con=new mysqli("localhost","root","","userdatabase");
$q="update historicaldata set movieName='".$movieName."',actor='".$Character1."',actress='".$Character2."',date='".$dateRel."',producerName='".$producerN."',directorName='".$directorN."',writtenBy='".$writtenBy."',budget=".$budget.",runningTime=".$runningTime.",result='".$outcome."'where mvid=".$inworkid;


if($con->query($q)==TRUE)
{
	header("Location:viewHistoricalData.php");
}
else{	
	echo $con->error;
}
	$con->close();
?>

