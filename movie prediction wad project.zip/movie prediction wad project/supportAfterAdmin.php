<?php
$movieName=$_POST["movieName"];
$Character1=$_POST["Character1"];
$Character2=$_POST["Character2"];
$dateRel=$_POST["date"];
$producerN=$_POST["producerName"];
$directorN=$_POST["directorName"];
$writtenBy=$_POST["writtenBy"];
$budget=$_POST["budget"];
$runningTime=$_POST["runningTime"];
$outcome=$_POST["result"];
//created connection
$con=new mysqli("localhost","root","","userdatabase");

$q="insert into  historicaldata(movieName,actor,actress, date, producerName,directorName,writtenBy,budget, runningTime, result) values('".$movieName."','".$Character1."','".$Character2."','".$dateRel."','".$producerN."','".$directorN."','".$writtenBy."',".$budget.",".$runningTime.",'".$outcome."')";
if($con->query($q)==TRUE)
{
?>
<script type="text/javascript">
	alert("Data Inserted,Thank You");
 	window.location.replace('afterAdminSignIn.php');		
</script>
<?php
}
else
{
	echo $con->error;
}


$con->close();
?>