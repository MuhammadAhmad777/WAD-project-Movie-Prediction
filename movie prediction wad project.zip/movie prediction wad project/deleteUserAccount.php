<?php
	session_start();
		if (isset($_SESSION["adminName"]))
		{
			$con=new mysqli("localhost","root","","userdatabase");
			$q = "delete from useraccounts where email='".$_GET["email"]."'";
			if($con->query($q)==TRUE){
				
				header("Location:viewUserAccounts.php");

			}else{
				echo $con->error;
			
			}

		    $con->close();
		}
		else
		{
			echo "You're already signed out";
		}
?>

