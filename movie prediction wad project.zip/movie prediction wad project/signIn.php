<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
	<title>M2A Movie Predictor Sign in</title>
	<meta content="" name="description">
  <meta content="" name="keywords">
  <!--logo-->
  	 <link href="associated/img/logoM2A.png" rel="icon">
  <!--style css-->
	 <link href="associated/css/userPages.css" rel="stylesheet">
  <!--bootstrap css-->
  <link href="associated/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">

</head>
<body>

<!-- ======= Hero Section ======= -->
  <div id="hero" class="hero route bg-image" style="background-image: url(associated/img/filmbg.jpg)">
    <div class="overlay-itro"></div>
    <div class="hero-content display-table">
      <div class="table-cell">
        <div class="container">
			<h2 class="hero-title mb-4">Sign in</h2>
			<p class="hero-subtitle">Use your Account at M2A Movie Predictor</p>


			
			<form action="authentication.php" method="POST">
			Enter your Name
			<input type="text" name="name" placeholder="User Name" required><br><br>
			Enter your Email
			<input type="text" name="email" placeholder="User Email" required><br><br>
			Enter your Password
			<input type="password" name="password" placeholder="User Password" required><br><br>
			<input type="submit" value="Next" class="customButton"><br><br>
			<input type="reset" value="Clear it" class="customButton"><br><br>
			</form>
			<a href= "signUp.php" ><button class="customButton">Sign up instead</button></a>
		    <a href= "index.php" ><button class="customButton">Back to Home</button></a>

         
        </div>
      </div>
    </div>
  </div><!-- End Hero Section -->

</body>
</html>