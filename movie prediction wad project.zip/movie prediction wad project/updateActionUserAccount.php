<?php
	$n = $_POST["name"];
	$prevEmail = $_POST["email"];
	$p = $_POST["password"];
	$newEmail= $_POST["newemail"];
	$con=new mysqli("localhost","root","","userdatabase");
	$q = "update useraccounts set name ='".$n."',password='".$p."',email='".$newEmail."'where email='".$prevEmail."'";
	if($con->query($q)==TRUE){
		header("Location:viewUserAccounts.php");
	}else{
		
		echo $con->error;

	
	}

		$con->close();
?>

