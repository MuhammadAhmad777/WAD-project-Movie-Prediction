<?php

$n=$_POST["admName"];
$e=$_POST["email"];
$p=$_POST["password"];

$con=new mysqli("localhost","root","","userdatabase");
$q="select * from admin where adminName='$n' AND email='$e' AND password='$p'";	
$rs = $con->query($q);
if($rs->num_rows ==1)
{
	session_start();
	$_SESSION["adminName"]=$n;
	$_SESSION["email"]=$e;
	$_SESSION["password"]=$p;
	header("Location:afterAdminSignIn.php");
}
else
{
	header("Location:adminSignIn.php");
}
$con->close();

?>