
<!DOCTYPE html>
<html>
<head>
	<title>M2A Predict Now</title>
	 <link href="associated/img/logoM2A.png" rel="icon">
	 <!--css file-->
  	 <link rel="stylesheet" type="text/css" href="associated/css/userPages.css">
  	 <!--bootstrap css-->
  	 <link href="associated/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>


<!-- ======= Hero Section ======= -->
  <div id="hero" class="hero route bg-image" style="background-image: url(associated/img/roll.jpg)">
    <div class="overlay-itro"></div>
    <div class="hero-content display-table">
    <?php
		session_start();
		if (isset($_SESSION["name"]))
		{
	?>
      <div class="table-cell">
        <div class="container">
			<h2 class="hero-title mb-4">Predict movie success</h2>
			<p class="hero-subtitle">Insert required factors for movie prediction</p>
			<form action="supportAfterSignIn.php" method="POST">
			<table cellpadding="10px">
				
				<tr>
					<td>Movie Name
					<input type="text" name="movieName" placeholder="Movie Name" required>
					</td>
					<td>Male
					<input type="text" name="Character1" placeholder="Leading Actor" required>
					</td>
					<td>Female
					<input type="text" name="Character2" placeholder="Leading Actress" required>
					</td>
				</tr>
				<tr>
					<td>Release Date
					<input type="date" name="date" placeholder="Date" required>
					</td>
					<td>Produced By
					<input type="text" name="producerName" placeholder="Producer Name" required>
					</td>
					<td>Directed By
					<input type="text" name="directorName" placeholder="Director Name" required>
					</td>
				</tr>
				<tr>
					<td>Written By
					<input type="text" name="writtenBy" placeholder="Writter Name" required>
					</td>
					<td>Budget
					<input type="text" name="budget" placeholder="Budget(US$ million)" required>
					</td>
					<td>Running Time
					<input type="text" name="runningTime" placeholder="Running Time(minutes)" required>
					</td>
				</tr>
			</table>
				<input type="submit" value="Predict Now" class="customButton">
				<input type="reset" value="Clear it" class="customButton"><br><br>
         	</form>
         	<a href= "signedout.php" ><button class="customButton">Sign out</button></a>

        </div>
      </div>
      <?php
		
		}
		else
		{
			echo "You're already signed out";
		}
	  ?>
    </div>
  </div><!-- End Hero Section -->
</body>
</html>

