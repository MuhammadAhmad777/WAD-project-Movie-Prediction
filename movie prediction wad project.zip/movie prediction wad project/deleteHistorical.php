<?php
	session_start();
		if (isset($_SESSION["adminName"]))
		{
			$con=new mysqli("localhost","root","","userdatabase");
			$q = "delete from historicaldata where mvid='".$_GET["id"]."'";
			if($con->query($q)==TRUE){
				
				header("Location:viewHistoricalData.php");

			}else{
				echo $con->error;
			
			}

		    $con->close();
		}
		else
		{
			echo "You're already signed out";
		}
?>

